
jQuery(document).ready(function(){
	jQuery("#back-top").hide();
	// fade in #back-top
	jQuery(function () {
		jQuery(window).scroll(function () {
			if (jQuery(this).scrollTop() > 100) {
				jQuery('#back-top').fadeIn();
			} else {
				jQuery('#back-top').fadeOut();
			}
		});
		// scroll body to 0px on click
		jQuery('#back-top').click(function () {
			jQuery('body,html').animate({
				scrollTop: 0
			}, 800);
			return false;
		});
	});
	if($('#sd-ship-recalculate').val()) {
		$('#sd-ship-recalculate').before('<input type="text" value="" placeholder="ZIP/Postal" name="" maxlength="20" size="10" id="js-ship-zip" style="border: 2px solid #eee;border-radius:5px; padding: 5px;box-shadow: 0 1px 1px #bfbfbf inset;">');
	
		if ($('#sd-ship-location').val() == 'OtherAddress') {
			$('#js-ship-zip').val($('#sd-s-zip').val());
		}
		else {
			$('#js-ship-zip').val($('#sd-b-zip').val());
		}
	
		$('#js-ship-zip').keyup(function () {
	
			if ($('#sd-ship-location').val() == 'OtherAddress') {
				$('#sd-s-zip').val($('#js-ship-zip').val());
			}
			else {
				$('#sd-b-zip').val($('#js-ship-zip').val());
			}
		});
	}
});

