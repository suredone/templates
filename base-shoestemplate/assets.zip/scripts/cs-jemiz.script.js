
var touch = false, clickEv = 'click';

/* Handle detect platform */
function handleDetectPlatform(){
  /* DETECT PLATFORM */
  jQuery.support.touch = 'ontouchend' in document;
  
  if (jQuery.support.touch) {
    touch = true;
    jQuery('body').addClass('touch');
    clickEv = 'touchstart';
  }
  else{
    jQuery('body').addClass('notouch');
    if (navigator.appVersion.indexOf("Mac")!=-1){
      if (navigator.userAgent.indexOf("Safari") > -1){
        jQuery('body').addClass('macos');
      }
      else if (navigator.userAgent.indexOf("Chrome") > -1){
        jQuery('body').addClass('macos-chrome');
      }
        else if (navigator.userAgent.indexOf("Mozilla") > -1){
          jQuery('body').addClass('macos-mozilla');
        }
    }
  }
}

/* Fucntion get width browser */
function getWidthBrowser() {
	var myWidth;

	if( typeof( window.innerWidth ) == 'number' ) { 
		//Non-IE 
		myWidth = window.innerWidth;
		//myHeight = window.innerHeight; 
	} 
	else if( document.documentElement && ( document.documentElement.clientWidth || document.documentElement.clientHeight ) ) { 
		//IE 6+ in 'standards compliant mode' 
		myWidth = document.documentElement.clientWidth; 
		//myHeight = document.documentElement.clientHeight; 
	} 
	else if( document.body && ( document.body.clientWidth || document.body.clientHeight ) ) { 
		//IE 4 compatible 
		myWidth = document.body.clientWidth; 
		//myHeight = document.body.clientHeight; 
	}
	
	return myWidth;
}

// handle Animate
function setAnimate() {
  if(jQuery(window).innerWidth() > 768 ){
    var ani = '100%';
    if(index==1) ani='50%';
  	jQuery('.left-search-block, .right-links-blocks').waypoint(function() {
		if ( !jQuery( this ).hasClass( "animated" ) ){
      jQuery(this).toggleClass('animated fadeInDown');
	}},
	{ offset: '100%' });
      
    jQuery('.nav-logo, .nav-menu, .shopby-collections-wrapper, .product-detail-content #product-image #gallery-images, #order_payment').waypoint(function() {
	if ( !jQuery( this ).hasClass( "animated" ) ){
      jQuery(this).toggleClass('animated fadeInLeft');
	}},
	{ offset: '100%' });
    
    jQuery('#tabpanel, #home-banner, #home-browser-collections, .blog-content .article, .blogs-item .blog-group, .comments .comment, .comment_form, .product-detail-content #product-image #featuted-image, .product-detail-content #tabs-information, .related-products, #customer_orders, #order_details, #wish-list .table-cart').waypoint(function() {
	if ( !jQuery( this ).hasClass( "animated" ) ){
      jQuery(this).toggleClass('animated fadeInUp');
	}},
	{ offset: ani });
      
    jQuery('#footer-top, #footer-infomation, #footer-links, #footer-bottom').waypoint(function() {
	if ( !jQuery( this ).hasClass( "animated" ) ){
      jQuery(this).toggleClass('animated fadeInUp');
	}},
	{ offset: ani });
      
    jQuery('#home-browser-collections .home-collections-links li, #collections-listing ul li.link-element').waypoint(function() {
	if ( !jQuery( this ).hasClass( "animated" ) ){
      jQuery(this).toggleClass('animated flipInX');
	}},
	{ offset: ani });
    jQuery('.sidebar .sb-item, .product-detail-content #product-information, #customer_sidebar, #order_shipping').waypoint(function() {
	if ( !jQuery( this ).hasClass( "animated" ) ){
      jQuery(this).toggleClass('animated fadeInRight');
	}},
	{ offset: ani });
  }
}
                                               
/* Handle dropdown box */
function handleDropdown(){
  if(jQuery('.dropdown-toggle').length){
    jQuery('.dropdown-toggle').parent().hover(function (){
      if(touch == false && getWidthBrowser() > 767 ){
        jQuery(this).find('.dropdown-menu').stop(true, true).slideDown(300);
      }
    }, function (){
      if(touch == false && getWidthBrowser() > 767 ){
        jQuery(this).find('.dropdown-menu').hide();
      }
    });
  }
  
  jQuery('nav .dropdown-menu').each(function(){
    jQuery(this).find('li').last().addClass('last');
  });
  
  jQuery('.dropdown').on('click', function() {
      if(touch == false && getWidthBrowser() > 767 ){
        var href = jQuery(this).find('.dropdown-link').attr('href');
        window.location = href;
    }
  });
  
  jQuery('.cart-link').on('click', function() {
      if(touch == false && getWidthBrowser() > 767 ){
        var href = jQuery(this).find('.dropdown-link').attr('href');
        window.location = href;
    }
  });
}

/* Log-in Dropdown */
function handleLogin(){
  jQuery("#loginBox input").focus(function() {
    jQuery(this).parents('#loginBox').addClass('focus');
  }).blur(function() {
    jQuery(this).parents('#loginBox').removeClass('focus');
  });
}
      
/* Full Width Carousel */
function handleFlexCasousel(){
  var animate,text;
    if ( jQuery('.slides li').size() > 1 ) {
    jQuery('.home-slideshow').flexslider({
      namespace: "jemiz-",
      slideshow: true,
      animation: "fade",
      slideshowSpeed:5000,
      directionNav: false,
      controlNav: true,
      pauseOnHover: false,
      randomize:false,
      smoothHeight: true,
      directionNav: false,
      start: function(){
        jQuery('.home-slideshow-wrapper').css({"overflow":"","height":"" });
      	jQuery('.home-slideshow').css("opacity","1"); 
        jQuery('.home-slideshow-loader').hide();
      	jQuery( ".home-slideshow .slides li" ).each(function() {
     	 if(jQuery(this).hasClass("jemiz-active-slide")){
      		jQuery(this).children('div').addClass("animated");
      		jQuery(this).children('div').each(function() {
              if(jQuery(this).hasClass("action")){
                animate = jQuery(this).attr('data-jemiz-animate');
      			jQuery(this).addClass(animate);
                text = jQuery(this).attr('data-jemiz-text');
                jQuery(this).children('a').html("<span>"+text+"</span>");
              }
              else{
      			animate = jQuery(this).attr('data-jemiz-animate');
      			jQuery(this).addClass(animate);
      			text = jQuery(this).attr('data-jemiz-text');
      			jQuery(this).html("<span>"+text+"</span>");
              }
    		});
    	 }	
         else{
            jQuery(this).children('div').removeClass("animated");
      		jQuery(this).children('div').each(function() {
              if(jQuery(this).hasClass("action")){
           		animate = jQuery(this).attr('data-jemiz-animate');
      			jQuery(this).removeClass(animate);
      			jQuery(this).children('a').html("");
              }else{
                animate = jQuery(this).attr('data-jemiz-animate');
      			jQuery(this).removeClass(animate);
      			jQuery(this).html("");
              }
            });
         }
    	});
      },
      after: function(){
      	jQuery( ".home-slideshow .slides li" ).each(function() {
     	 if(jQuery(this).hasClass("jemiz-active-slide")){
      		jQuery(this).children('div').addClass("animated");
            jQuery(this).children('div').each(function() {
              if(jQuery(this).hasClass("action")){
                animate = jQuery(this).attr('data-jemiz-animate');
      			jQuery(this).addClass(animate);
                text = jQuery(this).attr('data-jemiz-text');
                jQuery(this).children('a').html("<span>"+text+"</span>");
              }
              else{
      			animate = jQuery(this).attr('data-jemiz-animate');
      			jQuery(this).addClass(animate);
              	text = jQuery(this).attr('data-jemiz-text');
      			jQuery(this).html("<span>"+text+"</span>");
              }
    		});
    	 }	
         else{
            jQuery(this).children('div').removeClass("animated");
            jQuery(this).children('div').each(function() {
              if(jQuery(this).hasClass("action")){
           		animate = jQuery(this).attr('data-jemiz-animate');
      			jQuery(this).removeClass(animate);
      			jQuery(this).children('a').html("");
              }else{
           		animate = jQuery(this).attr('data-jemiz-animate');
      			jQuery(this).removeClass(animate);
      			jQuery(this).html("");
              }
            });
         }
    	});
      }
    });

  }
}

/* Parallax Carousel and Opacity Caption*/
function parallaxOpacityCarousel() {
  jQuery(document).scroll(function(){
  	var scrollPos = jQuery(this).scrollTop();
  	jQuery('.caption-text').css({'opacity' : 1-(scrollPos*2/jQuery(window).innerHeight())});
    //jQuery(".slides img").css("transform","translateY(" +  -(scrollPos/4)  + "px)");
  });
}
      
/* Function update scroll product thumbs */
function updateScrollThumbsQS(){
  if(jQuery('#gallery_main_qs').length){
    
    jQuery('#quick-shop-image .fancybox').on(clickEv, function() {
      var _items = [];
      var _index = 0;
      var product_images = jQuery('#gallery_main_qs .image-thumb');
      product_images.each(function(key, val) {
        _items.push({'href' : val.href, 'title' : val.title});
        if(jQuery(this).hasClass('active')){
          _index = key;
        }
      });
      jQuery.fancybox(_items,{
        closeBtn: true,
        index: _index,
        helpers: {
          buttons: {}
        }
      });
      return false;
    });

    jQuery('#quick-shop-image').on(clickEv, '.image-thumb', function() {

      var $this = jQuery(this);
      var background = jQuery('.product-image .main-image .main-image-bg');
      var parent = $this.parents('.product-image-wrapper');
      var src_original = $this.attr('data-image-zoom');
      var src_display = $this.attr('data-image');
      
      background.show();
      
      parent.find('.image-thumb').removeClass('active');
      $this.addClass('active');
      
      parent.find('.main-image').find('img').attr('data-zoom-image', src_original);
      parent.find('.main-image').find('img').attr('src', src_display).load(function() {
        background.hide();
      });
      
      return false;
    });
  }
}
                                                                     
/* Carousel Product*/
function HandleCarousel(){
  /* Collection Carousel */
  if(jQuery(".home-collections-links").length){
    jQuery(".home-collections-links").owlCarousel({
      navigation : true,
      pagination: false,
      autoPlay: true,
      items: 4,
      slideSpeed : 200,
      paginationSpeed : 800,
      rewindSpeed : 1000,
      itemsDesktop : [1199,4],
      itemsDesktopSmall : [979,3],
      itemsTablet: [768,3],
      itemsTabletSmall: [540,2],
      itemsMobile : [360,1],
      navigationText: ['<i class="fa fa-angle-left" title="Previous" data-toggle="tooltip" data-placement="top"></i>', '<i class="fa fa-angle-right" title="Next" data-toggle="tooltip" data-placement="top"></i>']
    });
  }
  
  /* New Arrival Carousel */
  if(jQuery(".new-arrival-content").length){
    jQuery(".new-arrival-content").owlCarousel({
      navigation : true,
      pagination: false,
      items: 4,
      slideSpeed : 200,
      paginationSpeed : 800,
      rewindSpeed : 1000,
      itemsDesktop : [1199,4],
      itemsDesktopSmall : [979,3],
      itemsTablet: [768,3],
      itemsTabletSmall: [540,2],
      itemsMobile : [360,1],
      navigationText: ['<i class="fa fa-angle-left" title="Previous" data-toggle="tooltip" data-placement="top"></i>', '<i class="fa fa-angle-right" title="Next" data-toggle="tooltip" data-placement="top"></i>']
    });
  }
  
  if(jQuery(".related-products ul.related-products-items").length){
    jQuery(".related-products ul.related-products-items").owlCarousel({
      navigation : true,
      pagination: false,
      items: 4,
      slideSpeed : 200,
      paginationSpeed : 800,
      rewindSpeed : 1000,
      itemsDesktop : [1199,4],
      itemsDesktopSmall : [979,3],
      itemsTablet: [768,3],
      itemsTabletSmall: [540,2],
      itemsMobile : [360,1],
      navigationText: ['<i class="fa fa-angle-left" title="Previous" data-toggle="tooltip" data-placement="top"></i>', '<i class="fa fa-angle-right" title="Next" data-toggle="tooltip" data-placement="top"></i>']
    });
  }
  
  if(jQuery("#gallery-images-mobile .vertical-slider").length){
    jQuery("#gallery-images-mobile .vertical-slider").owlCarousel({
      navigation : true,
      pagination: false,
      items: 4,
      slideSpeed : 200,
      paginationSpeed : 800,
      rewindSpeed : 1000,
      itemsDesktop : [1199,4],
      itemsDesktopSmall : [979,4],
      itemsTablet: [768,4],
      itemsTabletSmall: [540,4],
      itemsMobile : [360,4],
      navigationText: ['<i class="fa fa-angle-left" title="Previous" data-toggle="tooltip" data-placement="top"></i>', '<i class="fa fa-angle-right" title="Next" data-toggle="tooltip" data-placement="top"></i>']
    });
  }
  
  jQuery("#gallery-images .vertical-slider").bxSlider({
      mode: 'vertical',
      slideWidth: 100,
      minSlides: 4,
      nextText: '<i class="fa fa-angle-up" title="Previous" data-toggle="tooltip" data-placement="top"></i>',
      prevText: '<i class="fa fa-angle-down" title="Next" data-toggle="tooltip" data-placement="top"></i>',
      hideControlOnEnd: true,
      infiniteLoop: false,
      pager: false,
      slideMargin: 0
  });
}
      
// handle scroll-to-top button
function handleScrollTop() {
  function totop_button(a) {
    var b = jQuery("#scroll-to-top");
    b.removeClass("off on");
    if (a == "on") { b.addClass("on") } else { b.addClass("off") }
  }
  jQuery(window).scroll(function() {
    var b = jQuery(this).scrollTop();
    var c = jQuery(this).height();
    if (b > 0) { 
      var d = b + c / 2;
    } 
    else { 
      var d = 1 ;
    }    
    if (d < 1e3 && d < c) { 
      totop_button("off");
    } 
    else {
      totop_button("on"); 
    }
  });  
  jQuery("#scroll-to-top").click(function (e) {
    e.preventDefault();
    jQuery('body,html').animate({scrollTop:0},800,'swing');
  });
}    
      
function ModalNewsletter(){
  
  	if (jQuery.cookie('jemiz-cookie') != "active"){
  		jQuery('#newsletter-popup').modal('toggle');
  		jQuery('.nl-wraper-popup').addClass('animated'); 
    }
  
}
      
function checkcookie(){
    jQuery.cookie('jemiz-cookie', 'active', { expires: 10});
}
      
function autocompleteSearch(){
  var currentAjaxRequest = null;  
  var searchForms = jQuery('form[action="/search"]').css('position','relative').each(function() {    
    var input = jQuery(this).find('input[name="q"]');    
    var offSet = input.position().top + input.innerHeight();
    jQuery('<ul class="search-results"></ul>').css( { 'position': 'absolute', 'left': '0px', 'top': offSet } ).appendTo(jQuery(this)).hide();    
    input.attr('autocomplete', 'off').bind('keyup change', function() {
      var term = jQuery(this).val();
      var form = jQuery(this).closest('form');
      var searchURL = '/search?type=product&q=' + term;
      var resultsList = form.find('.search-results');      
      if (term.length > 3 && term != jQuery(this).attr('data-old-term')) {      
        jQuery(this).attr('data-old-term', term);      
        if (currentAjaxRequest != null) currentAjaxRequest.abort();     
        currentAjaxRequest = jQuery.getJSON(searchURL + '&view=json', function(data) {          
          resultsList.empty();          
          if(data.results_count == 0) {          
            resultsList.hide();
          } else {         
            jQuery.each(data.results, function(index, item) {
              var link = jQuery('<a></a>').attr('href', item.url);
              link.append('<span class="thumbnail"><img src="' + item.thumbnail + '" /></span>');
              link.append('<span class="title">' + item.title + '</span>');
              link.wrap('<li></li>');
              resultsList.append(link.parent());
            });      
            if(data.results_count > 10) {
              resultsList.append('<li><span class="title"><a href="' + searchURL + '">See all results (' + data.results_count + ')</a></span></li>');
            }
            resultsList.fadeIn(200);
          }        
        });
      }
    });
  });
  jQuery('body').bind('click', function(){
    jQuery('.search-results').hide();
  });
}

/* Handle Grid - List */
function handleGridList(){
  
  
  if(jQuery('#goList').length){
    jQuery('#goList').on(clickEv, function(e){
      jQuery(this).parent().find('li').removeClass('active');
      jQuery(this).addClass('active');
      jQuery('#sandBox .element').addClass('full_width');
      jQuery('#sandBox .element').removeClass('no_full_width');
      jQuery('#sandBox .element .row-left').addClass('col-md-4');
      jQuery('#sandBox .element .row-right').addClass('col-md-8');
      jQuery('#sandBox .element').removeClass('animated flipInX');
      jQuery('#sandBox .element').addClass('jemiz-animated');
      jQuery('#sandBox').isotope('layout');
    });
  }
  
  if(jQuery('#goGrid').length){
    jQuery('#goGrid').on(clickEv, function(e){
      jQuery(this).parent().find('li').removeClass('active');
      jQuery(this).addClass('active');
      jQuery('#sandBox .element').removeClass('full_width');
      jQuery('#sandBox .element').addClass('no_full_width');
      jQuery('#sandBox .element .row-left').removeClass('col-md-4');
      jQuery('#sandBox .element .row-right').removeClass('col-md-8');
      jQuery('#sandBox').isotope('layout');
    });
  }
}
      
/* Handle product quantity */
function handleQuantity(){
  if(jQuery('.quantity-wrapper').length){
    jQuery('.quantity-wrapper').on(clickEv, '.qty-up', function() {
      var $this = jQuery(this);

      var qty = $this.data('src');
      jQuery(qty).val(parseInt(jQuery(qty).val()) + 1);
    });
    jQuery('.quantity-wrapper').on(clickEv, '.qty-down', function() {
      var $this = jQuery(this);

      var qty = $this.data('src');

      if(parseInt(jQuery(qty).val()) > 1)
        jQuery(qty).val(parseInt(jQuery(qty).val()) - 1);
    });
  }
}
      
function colorwarches(){
   jQuery('.swatch :radio').change(function() {
     var optionIndex = jQuery(this).closest('.swatch').attr('data-option-index');
     var optionValue = jQuery(this).val();
     jQuery(this)
       .closest('form')
       .find('.single-option-selector')
       .eq(optionIndex)
       .val(optionValue)
       .trigger('change');
   }); 
}

/* Handle Map with GMap */
function handleMap(){
  if(jQuery().gMap){
    if(jQuery('#contact_map').length){
      jQuery('#contact_map').gMap({
        zoom: 17,
        scrollwheel: true,
        maptype: 'ROADMAP',
        markers:[
          {
            address: '474 Ontario St Toronto, ON M4X 1M7 Canada',
            html: '_address'
          }
        ]
      });
    }
  }
}      

function toggleLeftMenu(){ 
  if(window.innerWidth <= 1199 ){
    var menuLeft = document.getElementById( 'is-mobile-nav-menu' ),				
        showLeftPush = document.getElementById( 'showLeftPush' ),	
        rightcontent = document.getElementById( 'right-content' ),
        body = document.body;			
    showLeftPush.onclick = function() {
      classie.toggle( this, 'active' );
      classie.toggle( body, 'pushed' );
      classie.toggle( menuLeft, 'leftnavi-open' );
      classie.toggle( rightcontent, 'leftnavi-pushed' );
      if(classie.has( this, 'active' ))
        jQuery('#showLeftPush').html("<i class='fa fa-times fa-2x'></i>");
      else jQuery('#showLeftPush').html("<i class='fa fa-bars fa-2x'></i>");
    };
  }
};
      
function toggleTagsFilter(){ 
  if(window.innerWidth >= 768 ){
    var tagsbutton = document.getElementById( 'showTagsFilter' ),				
        tagscontent = document.getElementById( 'tags-filter-content' );    
    if(tagsbutton != null ){
      tagsbutton.onclick = function() {
        classie.toggle( this, 'closed' );
        classie.toggle( tagscontent, 'tags-closed' );
        if(classie.has( this, 'closed' ))
          jQuery('#showTagsFilter').html("Filter <i class='fa fa-angle-down'></i>");
        else jQuery('#showTagsFilter').html("Filter <i class='fa fa-angle-up'></i>");
      };
    }
  }
}
      
jQuery( window ).resize(function() {
  toggleLeftMenu();
});
      
jQuery(window).ready(function($) {
  
  handleDetectPlatform();
  
   autocompleteSearch()  
  
  parallaxOpacityCarousel();
  
  updateScrollThumbsQS();
  
  handleDropdown();
  
  handleLogin();
  
  HandleCarousel();
  
  jQuery('#home-tabs a').click(function (e) {
    e.preventDefault();
    jQuery(this).tab('show');
  });
  
  jQuery('[data-toggle="tooltip"]').tooltip();  
  
  handleGridList();
  
  handleQuantity();
  
  colorwarches();
  
  handleScrollTop();
  
  handleMap();

  toggleLeftMenu();
  
  toggleTagsFilter();
  
});
     
      
jQuery(window).load(function() {
  jQuery("#loading-div").addClass("fadeOut animated");
  jQuery("#loading-div").fadeOut(800);
  
  handleFlexCasousel();

  ModalNewsletter();
  
  
  
});