/**
*	@name							Accordion
*	@descripton						This $jq plugin makes creating accordions pain free
*	@version						1.3
*	@requires						$jq 1.2.6+
*
*	@author							Jan Jarfalk
*	@author-email					jan.jarfalk@unwrongest.com
*	@author-website					http://www.unwrongest.com
*
*	@licens							MIT License - http://www.opensource.org/licenses/mit-license.php
*/

(function(jQuery){
     jQuery.fn.extend({  
         accordion: function() {       
            return this.each(function() {
            	
            	var $jqul = jQuery(this);
            	
				if($jqul.data('accordiated'))
					return false;
													
				jQuery.each($jqul.find('ul, li>div'), function(){
					jQuery(this).data('accordiated', true);
					jQuery(this).hide();
				});
				
				jQuery.each($jqul.find('span.head'), function(){
					jQuery(this).click(function(e){
						activate(this);
						return void(0);
					});
				});
				
				//var active = (location.hash)?jQuery(this).find('a[href=' + location.hash + ']')[0]:'';
                    var active = null;
				if(active){
					activate(active, 'toggle');
					jQuery(active).parents().show();
				}
				
				function activate(el,effect){
					jQuery(el).parent('li').toggleClass('active').siblings().removeClass('active').children('ul, div').slideUp('fast');
					jQuery(el).siblings('ul, div')[(effect || 'slideToggle')]((!effect)?'fast':null);
				}
				
            });
        } 
    }); 
})(jQuery);

jQuery(document).ready(function () {
	
	jQuery("ul.accordion li.parent").each(function(){
        jQuery(this).append('<span class="head"><a href="javascript:void(0)"></a></span>');
      });
	
	jQuery('ul.accordion').accordion();
	
	jQuery("ul.accordion li.active").each(function(){
		jQuery(this).children().next("ul").css('display', 'block');
	});
});