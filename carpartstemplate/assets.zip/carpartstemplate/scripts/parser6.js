/**
 * Created by eugene on 21.05.15.
 */
var csvContent;
var data;
var form = document.getElementById('fields');
var headers;
var vocabulary;
var vocabularyData;
var config = {
    userName: '',
    website: '',
    count: 2,
    target: 'epid-search',
    useLabels: true,
    headers: [],
    fieldIdx: [0]
};
var formTemplateBegin = "<form action='%URL%' method='post'>";
var formTemplateEnd = "<button disabled='disabled' type='button' id='%USER%-submit' onclick='%USER%FormSubmit();'>Search</button><button type='button' onclick='%USER%ResetForm();'>Reset</button></form>";
var labelAdd = '';
var selectAdd = " class='select-attributes'";
var handlerTemplate =
    "var %USER%_headers=%HEADERS%;\n" +
    "function %USER%GetCookie(name) {\n" +
    "var matches = document.cookie.match(new RegExp('(?:^|; )' + name + '=([^;]*)'));\n" +
    "return matches ? decodeURIComponent(matches[1]) : undefined;\n" +
    "}\n" +
    "function %USER%_set(e) {\n" +
    "if (!e) return;\n" +
    "var level = parseInt(e.attributes['data-level'].value), sel, curId, curdata, i;\n" +
    "var last = (level == COUNT - 1);\n" +
    "if (last && (e.selectedIndex > 0)) {\n" +
    "document.getElementById('%USER%-submit').disabled = null;\n" +
    "return;\n" +
    "}\n" +
    "if (last && (e.selectedIndex == 0)) {\n" +
    "document.getElementById('%USER%-submit').disabled = 'disabled';\n" +
    "return;\n" +
    "}\n" +
    "document.getElementById('%USER%-submit').disabled = 'disabled';\n" +
    "var selId = '%USER%-' + (level + 1);\n" +
    "sel = document.getElementById(selId);\n" +
    "sel.innerHTML = '';\n" +
    "curdata = %USER%_data;\n" +
    "for (i = level + 1; i < COUNT; i++) {\n" +
    "    curId = '%USER%-' + i;\n" +
    "    curId = document.getElementById(curId);\n" +
    "    curId.innerHTML = '<option value=\"\" >Select '+%USER%_headers[i]+'</option>';\n" +
    "    curId.value = '';\n" +
    "}\n" +
    "i = 1;\n" +
    "do {\n" +
    "    curId = document.getElementById('%USER%-' + (i)).value;\n" +
    "    curdata = curdata[curId];\n" +
    "} while (i++ < level);\n" +
    "var key, opt, sort=new Array();\n" +
    "for (key in curdata) {\n" +
    "    sort.push([%USER%_voc[level+1][key],key]);\n" +
    "}\n" +
    "sort.sort();\n" +
    "for (key in sort) {\n" +
    "    opt = document.createElement('option');\n" +
    "    opt.value =  sort[key][1];\n" +
    "    opt.innerHTML = sort[key][0];\n" +
    "    sel.appendChild(opt);\n" +
    "}\n}\n" +
    "function %USER%ResetForm() {\n" +
    "    document.cookie = 'q=; path=/;  expires=-1;';\n" +
    "    for (var i = 1; i < COUNT; i++) {\n" +
    "        document.cookie = '%USER%' + i + '=; path=/;  expires=-1;';\n" +
    "        document.getElementById('%USER%-'+i).value='';\n" +
    "    }\n" +
    "}\n" +
    "function %USER%FormSubmit(){\n" +
    "var date = new Date(new Date().getTime() + 24 * 3600 * 1000); //30*24*3600*1000\n" +
    "var level = COUNT-1;\n" +
    "var i = 2,curId;\n" +
    "curId = document.getElementById('%USER%-1').value;\n" +
    "document.cookie = '%USER%1=' + curId + '; path=/; expires=' + date.toUTCString();\n" +
    "var  cdata = %USER%_data[curId];\n" +
    "do {\n" +
    "curId = document.getElementById('%USER%-' + (i)).value;\n" +
    "document.cookie = '%USER%'+i+'='+curId+'; path=/; expires=' + date.toUTCString();\n" +
    "cdata = cdata[curId];\n" +
    "} while (i++ < level);\n" +
    "var search='ebaypid:'+cdata;\n"+
    "document.cookie = 'search=\"' + search + '\"; path=/;  expires=' + date.toUTCString();\n" +
    "window.location='%URL%'+search;\n" +
    "}\n" +
    "function %USER%loadForm(){\n" +
    "var el = document.getElementById('%TARGET%'); \nif (el) {el.innerHTML=filterTemplate;}else{return;}\n" +
    "var i = 1, curData;\n" +
    "do{ curData = %USER%GetCookie('%USER%'+i);\n" +
    "el=document.getElementById('%USER%-'+i);\n" +
    "if (curData) el.value=curData;\n" +
    "%USER%_set(el);i++;}while(curData && i <= COUNT);\n" +
    "}\n" +
    "if(window.addEventListener){\n" +
    "window.addEventListener('load',%USER%loadForm,false); //W3C\n" +
    "}\n" +
    "else{\n" +
    "window.attachEvent('onload',%USER%loadForm); //IE\n" +
    "}\n";

function csvJSON() {

    var lines = csvContent.split("\n");
    var str, currentline, j, i, un = 0, fldNo, curData, idx;
    csvContent = {};
    config.headers = [];
    vocabulary = {};
    vocabularyData = {};
    for (i = 0; i < config.fieldIdx.length; i++) {
        config.headers.push(headers[config.fieldIdx[i]]);
        vocabulary[i] = {};
        vocabularyData[i] = {};
    }
    console.log(config.fieldIdx);
    for (i = 1; i < lines.length-1; i++) {
        currentline = lines[i].replace(new RegExp('"', 'g'), '').split(",");
        curData = [];
        for (j = 1; j < config.fieldIdx.length; j++) {
            fldNo = config.fieldIdx[j];
            str = currentline[fldNo];
            if (typeof vocabulary[j][str] == 'undefined') {
                idx = parseInt(un++);
                vocabulary[j][str] = idx;
                vocabularyData[j][idx] = str;
                if (j == 1) {
                    console.log([idx, str]);
                }
            } else {
                idx = vocabulary[j][str];
            }
            curData[j] = idx;
            addContent(currentline, j, curData, j == config.fieldIdx.length - 1);
        }
    }
}

function addContent(dataLine, pos, cur, last) {

    if (pos == 1) {
        if (typeof csvContent[cur[1]] == 'undefined') {
            if (!last) csvContent[cur[1]] = {};
            else csvContent[cur[1]] = addEpids(csvContent[cur[1]], dataLine);
        }
    }
    if (pos == 2) {
        if (typeof csvContent[cur[1]][cur[2]] == 'undefined') {
            if (!last) csvContent[cur[1]][cur[2]] = {};
            else csvContent[cur[1]][cur[2]] = addEpids(csvContent[cur[1]][cur[2]], dataLine);
        }
    }
    if (pos == 3) {
        if (typeof csvContent[cur[1]][cur[2]][cur[3]] == 'undefined') {
            if (!last) csvContent[cur[1]][cur[2]][cur[3]] = {};
            else csvContent[cur[1]][cur[2]][cur[3]] = addEpids(csvContent[cur[1]][cur[2]][cur[3]], dataLine);
        }
    }
    if (pos == 4) {
        if (typeof csvContent[cur[1]][cur[2]][cur[3]][cur[4]] == 'undefined') {
            if (!last) csvContent[cur[1]][cur[2]][cur[3]][cur[4]] = {};
            else csvContent[cur[1]][cur[2]][cur[3]][cur[4]] = addEpids(csvContent[cur[1]][cur[2]][cur[3]][cur[4]], dataLine);
        }
    }
    if (pos == 5) {
        if (typeof csvContent[cur[1]][cur[2]][cur[3]][cur[4]][cur[5]] == 'undefined') {
            if (!last) csvContent[cur[1]][cur[2]][cur[3]][cur[4]][cur[5]] = {};
            else csvContent[cur[1]][cur[2]][cur[3]][cur[4]][cur[5]] = addEpids(csvContent[cur[1]][cur[2]][cur[3]][cur[4]][cur[5]], dataLine);
        }
    }
}

function addEpids(cval, dataLine) {
    if (typeof cval == 'undefined') {
        return [parseInt(dataLine[0])];
    } else {
        cval.push(parseInt(dataLine[0]));
        return cval;
    }
}

function readSingleFile(e) {
    var file = e.target.files[0];
    if (!file) {
        return;
    }
    showText('Loading file, please wait...');
    var reader = new FileReader();
    reader.onload = function (e) {
        csvContent = e.target.result;
        renderConfig();
        showText('');
    };
    reader.readAsText(file);
}

function showText(text) {
    var element = document.getElementById('file-content');
    element.innerHTML = text;
}

function appendText(text) {
    var element = document.getElementById('file-content');
    element.innerHTML = element.innerHTML + '</hr>' + text;
}

function genScript() {
    console.clear();
    form.style.display = 'none';
    showText('Checking configuration...<br>');
    if (!performCheck()) return false;
    console.log('start load');
    showText('Generation in progress...<br>');
    csvJSON();
    console.log('stop load');
    compressJson();
    console.log('compressed');

}

function performCheck() {
    var res;
    saveConfig();
    res = (config.userName.length !== 0);
    if (!res) {
        appendText('* Please set the user name<br>');
    }
    var tRes = (config.website.length !== 0);
    if (!tRes) {
        appendText('* Please set the search url<br>');
        res = false;
    }

    if (config.fieldIdx.length <= 2) {
        appendText('* Please add 2 or more fields<br>');
        res = false;
    }
    if (!res) {
        form.style.display = 'block';
    }
    return res;
}

function renderConfig() {
    var lines = csvContent.split("\n");
    headers = lines[0].split(",");

    var addon = document.getElementById('addon-fields');
    var s = '<option value="default" disabled="disabled">--Select one--</option>';
    var name = headers[0];

    for (var j = 1; j < headers.length; j++) {
        name = headers[j];
        s += "<option value=" + j + ">" + name + "</option>\n";
    }
    document.getElementById('f1').innerHTML = s;
    form.style.display = 'block';

    var button = document.getElementById('btn-generate');
    button.addEventListener('click', prepareScript);
    button = document.getElementById('btn-add');
    button.addEventListener('click', addNewFilter);

}

function prepareScript() {
    document.getElementById('start-gen').style.display = 'block';
    setTimeout(genScript, 200);
}

function saveConfig() {
    if (config.fieldIdx.length > 5) return false;
    config.fieldIdx = [0];
    for (var i = 1; i <= config.count; i++) {
        var el = document.getElementById('f' + i);
        if (el) {
            config.fieldIdx.push(el.value);
        }
    }
    config.userName = document.getElementById('username').value;
    config.website = document.getElementById('website').value;
    config.target = document.getElementById('target').value;
    config.useLabels = document.getElementById('useLabels').checked;
    return true;
}

function loadConfig() {
    for (var i = 1; i < config.count; i++) {
        var el = document.getElementById('f' + i);
        if (el) {
            el.value = config.fieldIdx[i];
        }
    }
    document.getElementById('username').value = config.userName;
    document.getElementById('website').value = config.website;
    document.getElementById('target').value = config.target;
    document.getElementById('useLabels').checked = config.useLabels;
}

function addNewFilter() {
    if (!saveConfig()) {
        alert('Maximum 5 filters');
        return;
    }
    var html = document.getElementById('first-filter').innerHTML;
    var div = document.getElementById('epid-search');
    div.innerHTML += "<div class='group'>" + html.replace(new RegExp('1', 'g'), config.count++) + "</div>";
    //restore select options
    var fromSelect = document.getElementById('f1');
    var toSelect = document.getElementById('f' + (config.count - 1));
    toSelect.innerHTML = fromSelect.innerHTML;
    loadConfig()
}

function replacer(s) {
    return s.replace(new RegExp('"', 'g'), '');
}


function compressJson() {
    vocabulary = null;
    data = csvContent;
    showText('Compressing JSON ... done');
    /* output to screen + demo */
    var formTmpl = formTemplateBegin.replace(new RegExp('%URL%', 'g'), config.website);
    var txt = document.getElementById('just-text');
    for (var j = 1; j < config.fieldIdx.length; j++) {
        if (j == 1) formTmpl += renderSelect(j, data);
        else formTmpl += renderSelect(j, []);
    }
    var sample = document.getElementById('filters-sample');
    document.getElementById('filters-head').style.display = 'block';
    txt.value = 'var filterTemplate="' + formTmpl + formTemplateEnd.replace(new RegExp('%USER%', 'g'), config.userName) + '";' + "\n";
    var script = handlerTemplate.replace(new RegExp('%USER%', 'g'), config.userName).replace(new RegExp('COUNT', 'g'), "" + config.fieldIdx.length)
        .replace(new RegExp('%URL%', 'g'), config.website).replace(new RegExp('%TARGET%', 'g'), config.target)
        .replace(new RegExp('%HEADERS%', 'g'), JSON.stringify(config.headers));
    sample.innerHTML = formTmpl + formTemplateEnd.replace(new RegExp('%USER%', 'g'), config.userName);
    var obj = document.createElement('script');
    obj.text = "var " + config.userName + "_data=data;\nvar " + config.userName + "_voc=vocabularyData;\n" + script
    + config.userName + "_set(document.getElementById('" + config.userName + '-1' + "'));";
    document.body.appendChild(obj);
    txt.value +=
        'var ' + config.userName + '_voc = ' + JSON.stringify(vocabularyData).replace(new RegExp('"[0-9]*"', 'g'), replacer) + ";\n" +
        'var ' + config.userName + '_data = ' + JSON.stringify(data).replace(new RegExp('"', 'g'), '') + ";\n" + script;
}

function renderSelect(id, keys) {
    var result = "";
    if (config.useLabels)
        result += "<label " + labelAdd + "for='" + config.userName + '-' + id + "'>" + headers[config.fieldIdx[id]] + "</label>";
    result += "<select name='" + config.userName + '_' + id + "' id='" + config.userName + '-' + id + "' data-level='" + id
    + "'" + selectAdd + " onchange='" + config.userName + "_set(this);'>";
    result += "<option value=''>Select " + headers[config.fieldIdx[id]] + '</option>';
    var sort = new Array();
    for (var key in keys) {
        sort.push([vocabularyData[1][key],key]);
    }
    sort.sort();
    for (var key in sort) {
        result += "<option value='" + sort[key][1] + "'>" + sort[key][0] + "</option>"
    }
    return result + "</select>";
}

/**
 * @return {string}

 function GetCookie(name) {
    var matches = document.cookie.match(new RegExp("(?:^|; )" + name + "=([^;]*)"));
    return matches ? decodeURIComponent(matches[1]) : undefined;
}

 function filterFormSubmit() {
    var level = config.fieldIdx.length - 1;
    var i = 2;
    var cdata = data[document.getElementById(config.userName + '-1').value], curId;
    do {
        curId = document.getElementById(config.userName + '-' + (i)).value;
        cdata = cdata[curId];
    } while (i++ < level);
    var date = new Date(new Date().getTime() + 24 * 3600 * 1000); //30*24*3600*1000
    document.cookie = 'q=epid:"' + cdata + '"; path=/;  expires=' + date.toUTCString();
    window.location = config.website + '?q=epid:"' + cdata + '"';
}
 */
document.getElementById('file-input')
    .addEventListener('change', readSingleFile, false);
document.getElementById('fields').style.display = 'none';

function suredoneFormSubmit(){
    var date = new Date(new Date().getTime() + 24 * 3600 * 1000); //30*24*3600*1000
    var level = 4-1;
    var i = 2,curId;
    curId = document.getElementById('suredone-1').value;
    document.cookie = 'suredone1=' + curId + '; path=/; expires=' + date.toUTCString();
    var  cdata = suredone_data[curId];
    do {
        curId = document.getElementById('suredone-' + (i)).value;
        document.cookie = 'suredone'+i+'='+curId+'; path=/; expires=' + date.toUTCString();
        cdata = cdata[curId];
    } while (i++ < level);
    var search='(';
    for (i=0;i<cdata.length;i++){
        search += 'ebayepid:'+cdata[i];
        if (i<cdata.left-1) search += ' ';
    }
    search +=')';
}