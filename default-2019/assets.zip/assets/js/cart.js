        $(function () {
            $('.product-image #wrap').click(function () {
                $(this).parent().find('a.lightbox').click();
            })
        });
        function sdAjaxCartCustom(form, key) {
            if (document.getElementById("sd-cart-form")) {
                sdcart = document.getElementById("sd-cart-form");
                sduri = sdcart.action;
                sddo = document.getElementById("sd-do");
                sdajaxstr = "do=" + sddo.value + "&sku=" + sdcart.sku.value;
                if (sdcart.guid && !isEmpty(sdcart.guid.value)) {
                    sdajaxstr = sdajaxstr + "&guid=" + sdcart.guid.value
                }
                if (sdcart.qty && !isEmpty(sdcart.qty.value)) {
                    sdajaxstr = sdajaxstr + "&qty=" + sdcart.qty.value
                }
                if (sdcart.title && !isEmpty(sdcart.title.value)) {
                    sdajaxstr = sdajaxstr + "&title=" + sdcart.title.value;
                    if (document.getElementById("sd-attr-temp") && !isEmpty($("#sd-title-temp").val())) {
                        sdajaxstr = sdajaxstr + " " + $("#sd-title-temp").val() + " " + $("#sd-guid option:selected").text().replace(/ - .?[0-9.]*$/, "")
                    } else if (!isEmpty($("#sd-guid option:selected").val())) {
                        sdajaxstr = sdajaxstr + " " + $("#sd-guid option:selected").text().replace(/ - .?[0-9.]*$/, "")
                    }
                }
                $("#sd-cart-image-" + key).attr("alt", "- - - checking - - -");
                $("#sd-cart-image-" + key).attr("title", "- - - checking - - -");
                sdajaxid = "sd-cart-status"
            } else if (document.getElementById("sd-cart-contents")) {
                sduri = location.pathname;
                sdajaxstr = form;
                sdajaxid = "sd-cart-contents"
            } else if (document.getElementById("sd-cart-form-" + key)) {
                sdcart = document.getElementById("sd-cart-form-" + key);
                sduri = sdcart.action;
                sddo = document.getElementById("sd-do-" + key);
                sdajaxstr = "do=" + sddo.value + "&sku=" + sdcart.sku.value;
                if (sdcart.guid && !isEmpty(sdcart.guid.value)) {
                    sdajaxstr = sdajaxstr + "&guid=" + sdcart.guid.value
                }
                if (sdcart.qty && !isEmpty(sdcart.qty.value)) {
                    sdajaxstr = sdajaxstr + "&qty=" + sdcart.qty.value
                }
                if (sdcart.title && !isEmpty(sdcart.title.value)) {
                    sdajaxstr = sdajaxstr + "&title=" + sdcart.title.value
                }
                $("#sd-cart-image-" + key).attr("alt", "- - - checking - - -");
                $("#sd-cart-image-" + key).attr("title", "- - - checking - - -");
                sdajaxid = "sd-cart-status-" + key
            }

            $.ajax({
                url: sduri + "?callback=?",
                crossDomain: true,
                dataType: "jsonp",
                data: sdajaxstr + "&call=ajax&sid=" + Math.random(),
                success: function (data) {
                    $("#" + sdajaxid).html(data.html);
                    $("#sd-do-cart").html(data.total);
                    $("#sd-do-cart-total").html(data.cart_total);
                    sdAjaxCartUpdate();
                }
            });
            return false
        }
        function sdAjaxCartUpdate() {
            $.ajax({
                url: sdcross_cart + '?callback=?',
                crossDomain: true,
                dataType: 'jsonp',
                data: 'do=status&call=ajax&sid=' + Math.random(),
                success: function (data) {
                    var items = 0;
                    var item, i;

                    if (data.cart_items) {
                        for (i = 1; i <= data.cart_items.index; i++) {
                            item = data.cart_items[i];
                            if (item.qty) items++;
                        }
                    }

                    $('.top-cart-price').html(
                        items
                    );
                }
            });
        }
