$(document).ready(function () {
    var menu_childs = $('.xt-dropdown > li').length;
    if (menu_childs > 10) {
        $('.xt-dropdown > li:gt(9)').hide('fast');
        $("<li class='view_more'><button class='show_more'>More Categories</button></li>").appendTo(".xt-dropdown");
        $('.view_more > button').on('click', function () {
            if ($('.view_more > button').hasClass('show_more')) {
                $('.xt-dropdown > li:gt(9)').show('slow');
                $('.xt-dropdown > li:gt(9)').css('overflow', 'visible');
                $('.view_more > button').removeClass('show_more');
                $('.view_more > button').addClass('show_less');
                $('.view_more > button').text('Less Categories');
                $("<li class='view_more'><button class='show_more'></button></li>").append(".xt-dropdown");
            } else if ($('.view_more > button').hasClass('show_less')) {
                $('.xt-dropdown > li:gt(9)').hide('slow');
                $('.view_more > button').text('More Categories');
                $("<li class='view_more'><button class='show_more'></button></li>").append(".xt-dropdown");
                $('.view_more > button').removeClass('show_less');
                $('.view_more > button').addClass('show_more');
                $('.view_more').show('fast');
            }
        });
    }
});