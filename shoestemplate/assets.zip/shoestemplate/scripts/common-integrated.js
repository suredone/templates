function redrawCart(cartData) {
    console.log(cartData);

    var cartDataItems = cartData.cart_items.index;
    var cart = $('#cart-target');

    var cartTotal = cart.find('.subtotal');
        cartTotal.html(
            cartDataItems + ' item(s) - ' + sdcurrency + cartData.cart_total
        );

    var cartContent = cart.find('#cart-info');
        cartContent.empty();

    if (cartDataItems > 0) {
        var itemsHtml = '';

        for (var i = 1; i <= cartDataItems; i++) {
            var item = cartData.cart_items[i];
            if (item.qty == 0) continue;

            var sku = item.guid ? item.guid : item.sku;
            var media = item.secure_media ? item.secure_media : item.media;
            var price = item.qty * item.sdprice;

            itemsImage = (
                item.galleryuri
                ? '<a class="cart-image"  href="/' + item.galleryuri + '" title="' + sku + ' Gallery"><img alt="' + item.title + '" src="' + media + '"/></a>'
                : '<img alt="' + item.title + '" src="' + media + '" />'
            );

            itemsHtml += (
            '<div class="row">'
                + '<div class="cart-left">'+itemsImage + '</div>'
                + '<div class="cart-right"><div class="cart-title"><a href="/' + item.uri + '">' + item.title + '</a></div>'
                + '<div class="cart-price">x&nbsp;'+ price +  '</div></div></div>'
            );
        }

        cartContent.append(
            '<div id="cart-content"><div class="items control-container">' + itemsHtml + '</div></div>'

            + '<div class="subtotal">'
                + '<tr>'
                    + ' <span class="cart-total-right" >' + sdcurrency + cartData.cart_total + '</span>'
                    + '<span>Subtotal:</span>'
                + '</tr>'
            + '</div>'

            + '<div class="action">'
                + '<button class="btn btn-3">View Cart<i class="fa fa-caret-right"></i></button>'
                + '<button class="btn btn-3 float-right">Checkout<i class="fa fa-caret-right"></i></button>>'
            + '</div>'
        );
    } else {
        cartContent.append(
            '<div class="empty">Your shopping cart is empty!</div>'
        );
    }
}

$(document).ready(function() {
    $.ajax({
        url: sdcross_cart + "?callback=?",
        crossDomain: true,
        dataType: "jsonp",
        data: "do=status&call=ajax&sid=" + Math.random(),
        success: function(data) {
            redrawCart(data);
        }
    });

    $('#cart > .heading a').live('click', function() {
        $('#cart').addClass('active');
        $('#cart').live('mouseleave', function() {
            $(this).removeClass('active');
        });
    });

	/* Mega Menu */
	$('#menu ul > li > a + div').each(function(index, element) {
		// IE6 & IE7 Fixes
		if ($.browser.msie && ($.browser.version == 7 || $.browser.version == 6)) {
			var category = $(element).find('a');
			var columns = $(element).find('ul').length;
			
			$(element).css('width', (columns * 143) + 'px');
			$(element).find('ul').css('float', 'left');
		}		
		
		var menu = $('#menu').offset();
		var dropdown = $(this).parent().offset();
		
		i = (dropdown.left + $(this).outerWidth()) - (menu.left + $('#menu').outerWidth());
		
		if (i > 0) {
			$(this).css('margin-left', '-' + (i + 5) + 'px');
		}
	});

	// IE6 & IE7 Fixes
	if ($.browser.msie) {
		if ($.browser.version <= 6) {
			$('#column-left + #column-right + #content, #column-left + #content').css('margin-left', '195px');
			
			$('#column-right + #content').css('margin-right', '195px');
		
			$('.box-category ul li a.active + ul').css('display', 'block');	
		}
		
		if ($.browser.version <= 7) {
			$('#menu > ul > li').bind('mouseover', function() {
				$(this).addClass('active');
			});
				
			$('#menu > ul > li').bind('mouseout', function() {
				$(this).removeClass('active');
			});	
		}
	}
	
	$('.success img, .warning img, .attention img, .information img').live('click', function() {
		$(this).parent().fadeOut('slow', function() {
			$(this).remove();
		});
	});
	
	if($('#sd-ship-recalculate').val()) {
        $('#sd-ship-recalculate').before('<input type="text" value="" placeholder="ZIP/Postal" name="" maxlength="20" size="10" id="js-ship-zip" style="border: 2px solid #eee;border-radius:5px; padding: 5px;box-shadow: 0 1px 1px #bfbfbf inset;">');

        if ($('#sd-ship-location').val() == 'OtherAddress') {
            $('#js-ship-zip').val($('#sd-s-zip').val());
        }
        else {
            $('#js-ship-zip').val($('#sd-b-zip').val());
        }

        $('#js-ship-zip').keyup(function () {

            if ($('#sd-ship-location').val() == 'OtherAddress') {
                $('#sd-s-zip').val($('#js-ship-zip').val());
            }
            else {
                $('#sd-b-zip').val($('#js-ship-zip').val());
            }
        });
    }

    $('#notification .close').click(function(){$('.success').fadeOut('slow');});
});

function getURLVar(key) {
	var value = [];
	
	var query = String(document.location).split('?');
	
	if (query[1]) {
		var part = query[1].split('&');

		for (i = 0; i < part.length; i++) {
			var data = part[i].split('=');
			
			if (data[0] && data[1]) {
				value[data[0]] = data[1];
			}
		}
		
		if (value[key]) {
			return value[key];
		} else {
			return '';
		}
	}
}

function sdAjaxCart2(form, key) {
    if (document.getElementById("sd-cart-form")) {
        sdcart = document.getElementById("sd-cart-form");
        sduri = sdcart.action;
        sddo = document.getElementById("sd-do");
        sdajaxstr = "do=" + sddo.value + "&sku=" + sdcart.sku.value;
        if (sdcart.guid && !isEmpty(sdcart.guid.value)) {
            sdajaxstr = sdajaxstr + "&guid=" + sdcart.guid.value
        }
        if (sdcart.qty && !isEmpty(sdcart.qty.value)) {
            sdajaxstr = sdajaxstr + "&qty=" + sdcart.qty.value
        }
        if (sdcart.title && !isEmpty(sdcart.title.value)) {
            sdajaxstr = sdajaxstr + "&title=" + sdcart.title.value;
            if (document.getElementById("sd-attr-temp") && !isEmpty($("#sd-title-temp").val())) {
                sdajaxstr = sdajaxstr + " " + $("#sd-title-temp").val() + " " + $("#sd-guid option:selected").text().replace(/ - .?[0-9.]*$/, "")
            } else if (!isEmpty($("#sd-guid option:selected").val())) {
                sdajaxstr = sdajaxstr + " " + $("#sd-guid option:selected").text().replace(/ - .?[0-9.]*$/, "")
            }
        }
        $("#sd-cart-image-" + key).attr("alt", "- - - checking - - -");
        $("#sd-cart-image-" + key).attr("title", "- - - checking - - -");
        sdajaxid = "sd-cart-status"
    } else if (document.getElementById("sd-cart-contents")) {
        sduri = location.pathname;
        sdajaxstr = form;
        sdajaxid = "sd-cart-contents"
    } else if (document.getElementById("sd-cart-form-" + key)) {
        sdcart = document.getElementById("sd-cart-form-" + key);
        sduri = sdcart.action;
        sddo = document.getElementById("sd-do-" + key);
        sdajaxstr = "do=" + sddo.value + "&sku=" + sdcart.sku.value;
        if (sdcart.guid && !isEmpty(sdcart.guid.value)) {
            sdajaxstr = sdajaxstr + "&guid=" + sdcart.guid.value
        }
        if (sdcart.qty && !isEmpty(sdcart.qty.value)) {
            sdajaxstr = sdajaxstr + "&qty=" + sdcart.qty.value
        }
        if (sdcart.title && !isEmpty(sdcart.title.value)) {
            sdajaxstr = sdajaxstr + "&title=" + sdcart.title.value
        }
        $("#sd-cart-image-" + key).attr("alt", "- - - checking - - -");
        $("#sd-cart-image-" + key).attr("title", "- - - checking - - -");
        sdajaxid = "sd-cart-status-" + key
    }


    $.ajax({
        url: "http://shoestemplate.suredone.com/cart?callback=?",
        crossDomain: true,
        dataType: "jsonp",
        data: sdajaxstr + "&call=ajax&sid=" + Math.random(),
        success: function (data) {
            $('#notification a.product-name-n').html($('#product .product-information ').text());
            $('html, body').animate({ scrollTop: 0 }, 'slow');
            $('.success').fadeIn('slow');

            redrawCart(data);

        }
    });
    return false;
}